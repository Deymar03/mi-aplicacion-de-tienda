// ========================= VENTAS.TSX COMPLETO =========================

import { ThemedView } from '@/components/themed-view';
import { TabHeader } from '@/components/tab-header';
import { ThemedText } from '@/components/themed-text';

import { Dimensions } from 'react-native';

import {
  LineChart,
} from 'react-native-chart-kit';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

import {
  StyleSheet,
  ScrollView,
  View,
  TouchableOpacity,
  Alert,
  Image,
  TextInput,
  Platform,
} from 'react-native';

import DateTimePicker from '@react-native-community/datetimepicker';

import { Colors } from '@/constants/theme';
import { useColorScheme } from '@/hooks/use-color-scheme';

import { useAuth } from '@/context/AuthContext';
import { useCart } from '@/context/CartContext';
import { useProducts } from '@/context/ProductContext';
import { useTransactions } from '@/context/TransactionContext';

import {
  useState,
  useMemo,
} from 'react';

/* ===================== HELPERS ===================== */


const formatFecha = (
  fecha: string
) => {
  return new Date(
    fecha
  ).toLocaleString('es-BO');
};

export default function VentasScreen() {
  
    const [
    reciboDetalle,
    setReciboDetalle,
  ] = useState<any>(null);

  const [
  historialVisible,
  setHistorialVisible,
] = useState(true);

  const colorScheme =
    useColorScheme();

  const colors =
    Colors[colorScheme ?? 'light'];

  const { user } = useAuth();

  const {
    items,
    calcularTotal,
    vaciarCarrito,
    removerDelCarrito,
    actualizarCantidad,
  } = useCart();

  const { reducirStock } =
    useProducts();

  const {
    registrarTransaccion,
    obtenerTransaccionesUsuario,
    obtenerTodasTransacciones,
  } = useTransactions();

  /* ===================== STATES ===================== */

  const [
    facturaVisible,
    setFacturaVisible,
  ] = useState(false);

const [
  factura,
  setFactura,
] = useState<any>(null);

  const [
    mostrarPago,
    setMostrarPago,
  ] = useState(false);

const qrImage = require(
  '../../assets/images/qr.jpg'
);
  const [mostrarQR, setMostrarQR] =
    useState(false);

  const [
    buscarCarnet,
    setBuscarCarnet,
  ] = useState('');

  const [
    buscarRecibo,
    setBuscarRecibo,
  ] = useState('');

  const [
    fechaInicio,
    setFechaInicio,
  ] = useState<Date | null>(
    null
  );

  const [fechaFin, setFechaFin] =
    useState<Date | null>(null);

  const [
    showInicioPicker,
    setShowInicioPicker,
  ] = useState(false);

  const [
    showFinPicker,
    setShowFinPicker,
  ] = useState(false);

  const total = calcularTotal();
  /* ===================== recibo imprimir ===================== */
const imprimirRecibo = async (
  recibo: any
) => {

    const cliente =
      recibo.cliente ||
      recibo.usuario_nombre;

    const metodo =
      recibo.metodoPago ||
      recibo.metodo_pago;

    const fecha =
      recibo.fecha ||
      recibo.created_at;

const html = `
<html>

<head>
<meta charset="UTF-8" />
<style>
@media print {

  body{
    padding:0;
    margin:0;
  }

  .print-container{
    width:100%;
    padding:20px;
  }

}

body{
  font-family: Arial;
  padding: 25px;
  color:#111827;
}

.title{
  text-align:center;
  font-size:28px;
  font-weight:bold;
  margin-bottom:25px;
}

.info-table{
  width:100%;
  border-collapse:collapse;
  margin-bottom:25px;
}

.info-table td{
  border:1px solid #d1d5db;
  padding:10px;
  font-size:14px;
}

.product-table{
  width:100%;
  border-collapse:collapse;
}

.product-table th{
  background:#111827;
  color:white;
  padding:12px;
  border:1px solid #374151;
  font-size:14px;
}

.product-table td{
  border:1px solid #d1d5db;
  padding:10px;
  font-size:13px;
  text-align:center;
}

.total-box{
  margin-top:25px;
  text-align:right;
  font-size:22px;
  font-weight:bold;
}

.footer{
  margin-top:40px;
  text-align:center;
  color:#6b7280;
  font-size:12px;
}

</style>
</head>

<body>

<div class="title">
RECIBO DIGITAL
</div>

<table class="info-table">

<tr>
<td>
<strong>ID RECIBO</strong>
</td>

<td>
${recibo.receipt_id}
</td>

<td>
<strong>MÉTODO</strong>
</td>

<td>
${
  recibo.metodoPago ||
  recibo.metodo_pago
}
</td>
</tr>

<tr>
<td>
<strong>CLIENTE</strong>
</td>

<td>
${
  recibo.cliente ||
  recibo.usuario_nombre
}
</td>

<td>
<strong>CARNET</strong>
</td>

<td>
${recibo.carnet || 'N/A'}
</td>
</tr>

<tr>
<td>
<strong>FECHA</strong>
</td>

<td colspan="3">
${formatFecha(
  recibo.fecha ||
  recibo.created_at
)}
</td>
</tr>




</table>

<table class="product-table">

<tr>
<th>PRODUCTO</th>
<th>DESCRIPCIÓN</th>
<th>CÓDIGO</th>
<th>CANTIDAD</th>
<th>P. UNITARIO</th>
<th>SUBTOTAL</th>
</tr>

${recibo.items
  .map(
    (item:any) => `
<tr>

<td>
${item.producto.nombre}
</td>

<td>
${
  item.producto.descripcion ||
  'Sin descripción'
}
</td>

<td>
${
  item.producto.codigoProducto ||
  'N/A'
}
</td>

<td>
${item.cantidad}
</td>

<td>
Bs. ${
  item.producto.precioVenta
}
</td>

<td>
Bs. ${
  item.cantidad *
  item.producto.precioVenta
}
</td>

</tr>
`
  )
  .join('')}

</table>

<div class="total-box">
TOTAL: Bs. ${recibo.total}
</div>

<div class="footer">
Gracias por su compra
</div>

</body>
</html>
`;

try {

if (Platform.OS === 'web') {

  const ventana =
    window.open(
      '',
      '_blank'
    );

  if (ventana) {

    ventana.document.write(
      html
    );

    ventana.document.close();

    ventana.focus();

    setTimeout(() => {
      ventana.print();
    }, 500);
  }

} else {

  const { uri } =
    await Print.printToFileAsync({
      html,
    });

  await Sharing.shareAsync(
    uri
  );
}

} catch (error) {

Alert.alert(
  'Error',
  'No se pudo imprimir'
);

}

};
  /* ===================== VENTAS ===================== */

  const ventas =
    user?.role === 'admin'
      ? obtenerTodasTransacciones()
      : obtenerTransaccionesUsuario(
          user?.id || ''
        );

  const ventasOrdenadas =
    useMemo(() => {
      const filtradas =
        ventas.filter((v: any) => {
          const carnetMatch =
            !buscarCarnet ||
            v.profiles?.carnet
              ?.toLowerCase()
              .includes(
                buscarCarnet.toLowerCase()
              );

          const reciboMatch =
            !buscarRecibo ||
            v.receipt_id
              ?.toLowerCase()
              .includes(
                buscarRecibo.toLowerCase()
              );

          const fechaVenta =
            new Date(v.created_at);

          let fechaMatch = true;

          if (fechaInicio) {
            fechaMatch =
              fechaVenta >=
              fechaInicio;
          }

          if (
            fechaFin &&
            fechaMatch
          ) {
            const fin =
              new Date(fechaFin);

            fin.setHours(
              23,
              59,
              59,
              999
            );

            fechaMatch =
              fechaVenta <= fin;
          }

          return (
            carnetMatch &&
            reciboMatch &&
            fechaMatch
          );
        });

      return [...filtradas].sort(
        (a, b) =>
          new Date(
            b.created_at
          ).getTime() -
          new Date(
            a.created_at
          ).getTime()
      );
    }, [
      ventas,
      buscarCarnet,
      buscarRecibo,
      fechaInicio,
      fechaFin,
    ]);

  const totalVentas =
    useMemo(() => {
      return ventasOrdenadas.reduce(
        (acc, t) =>
          acc + Number(t.total),
        0
      );
    }, [ventasOrdenadas]);
    
    const gananciaReal = useMemo(() => {
  return ventasOrdenadas.reduce(
    (totalGanancia: number, venta: any) => {

      const gananciaVenta =
        venta.items?.reduce(
          (subtotal: number, item: any) => {

            const precioVenta =
              Number(item.producto.precioVenta || 0);

            const precioCompra =
              Number(item.producto.precioCompra || 0);

            const cantidad =
              Number(item.cantidad || 0);

            return (
              subtotal +
              (precioVenta - precioCompra) *
                cantidad
            );
          },
          0
        ) || 0;

      return totalGanancia + gananciaVenta;
    },
    0
  );
}, [ventasOrdenadas]);
    
const chartData = {
  labels: ventasOrdenadas
    .slice(0, 6)
    .reverse()
    .map((v: any) =>
      new Date(
        v.created_at
      ).getDate().toString()
    ),

  datasets: [
    {
      data: ventasOrdenadas
        .slice(0, 6)
        .reverse()
        .map((v: any) =>
          Number(v.total)
        ),
    },
  ],
};
    
  /* ===================== COMPRA ===================== */

  const confirmarCompra =
    async (metodo: string) => {
      try {
        for (const item of items) {
          await reducirStock(
            item.producto.id,
            item.cantidad
          );
        }

        const transaccion =
          await registrarTransaccion(
            user?.id || '',
            user?.name ||
              'Cliente',
            items,
            total,
            metodo
          );

        setFactura({
          receipt_id:
            transaccion.receipt_id,

          fecha:
            transaccion.created_at,

          items: [...items],

          total,

          cliente:
            user?.name,

          carnet:
            user?.carnet || 'N/A',

          metodoPago: metodo,
        });

        setFacturaVisible(true);

        setMostrarPago(false);

        setMostrarQR(false);

        vaciarCarrito();

        Alert.alert(
          'Compra realizada ✔'
        );
      } catch (error) {
        Alert.alert(
          'Error',
          'No se pudo completar'
        );
      }
    };

    /* ===================== DETALLE RECIBO ADMIN ===================== */

if (reciboDetalle) {
  return (
    <ThemedView
      style={styles.container}
    >
      <TabHeader title="Detalle recibo" />

      <ScrollView
        contentContainerStyle={
          styles.contentContainer
        }
      >
        <View style={styles.factura}>
          <ThemedText type="title">
            RECIBO
          </ThemedText>

          <ThemedText>
            ID:
            {reciboDetalle.receipt_id}
          </ThemedText>

          <ThemedText>
            Cliente:
            {reciboDetalle.usuario_nombre}
          </ThemedText>

          <ThemedText>
            Fecha:
            {formatFecha(
              reciboDetalle.created_at
            )}
          </ThemedText>

          <ThemedText>
            Método:
            {reciboDetalle.metodo_pago}
          </ThemedText>

          {reciboDetalle.items?.map(
            (
              item: any,
              i: number
            ) => (
              <View
                key={i}
                style={styles.receiptCard}
              >
                <ThemedText
                  style={
                    styles.receiptProduct
                  }
                >
                  {
                    item.producto
                      .nombre
                  }
                </ThemedText>

                <View
                  style={
                    styles.receiptRow
                  }
                >
                  <ThemedText>
                    Cantidad:
                  </ThemedText>

                  <ThemedText>
                    {item.cantidad}
                  </ThemedText>
                </View>

                <View
                  style={
                    styles.receiptRow
                  }
                >
                  <ThemedText>
                    Unitario:
                  </ThemedText>

                  <ThemedText>
                    Bs.
                    {
                      item.producto
                        .precioVenta
                    }
                  </ThemedText>
                </View>

                <View
                  style={
                    styles.receiptRow
                  }
                >
                  <ThemedText>
                    Subtotal:
                  </ThemedText>

                  <ThemedText>
                    Bs.
                    {item.cantidad *
                      item.producto
                        .precioVenta}
                  </ThemedText>
                </View>
              </View>
            )
          )}

          <ThemedText
            style={styles.total}
          >
            TOTAL:
            Bs.
            {reciboDetalle.total}
          </ThemedText>

          {/* BOTON IMPRIMIR */}

          <TouchableOpacity
            style={[
              styles.btn,
              {
                backgroundColor:
                  '#22c55e',
                marginTop: 15,
              },
            ]}
onPress={() =>
  imprimirRecibo({
    ...reciboDetalle,
    cliente:
      reciboDetalle.usuario_nombre,

    carnet:
      reciboDetalle.profiles
        ?.carnet || 'N/A',

    metodoPago:
      reciboDetalle.metodo_pago,

    fecha:
      reciboDetalle.created_at,
  })
}
          >
            <ThemedText
              style={{
                color: colors.text,
              }}
            >
              Imprimir PDF
            </ThemedText>
          </TouchableOpacity>

          {/* BOTON CERRAR */}

          <TouchableOpacity
            style={[
              styles.btn,
              {
                backgroundColor:
                  '#ef4444',
                marginTop: 10,
              },
            ]}
            onPress={() =>
              setReciboDetalle(null)
            }
          >
            <ThemedText
              style={{
                color: colors.text,
              }}
            >
              Cerrar
            </ThemedText>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </ThemedView>
  );
}

  /* ===================== UI FACTURA ===================== */

  if (
    facturaVisible &&
    factura
  ) {
    return (
      <ThemedView
        style={styles.container}
      >
        <TabHeader title="RECIBO DIGITAL" />

        <ScrollView
  contentContainerStyle={
    styles.contentContainer
  }
  keyboardShouldPersistTaps="handled"
  showsVerticalScrollIndicator={false}
        >
          <View style={styles.factura}>
            <ThemedText type="title">
              Compra exitosa ✔
            </ThemedText>

            <ThemedText
              style={styles.receiptId}
            >
              ID:
              {
                factura.receipt_id
              }
            </ThemedText>

            <ThemedText>
              Cliente:
              {
                factura.cliente
              }
            </ThemedText>

            <ThemedText>
              Método:
              {
                factura.metodoPago
              }
            </ThemedText>

            <ThemedText>
              Fecha:
              {formatFecha(
                factura.fecha
              )}
            </ThemedText>

{factura.items.map(
  (
    item: any,
    i: number
  ) => (
    <View
      key={i}
      style={styles.receiptCard}
    >
      <ThemedText
        style={styles.receiptProduct}
      >
        {item.producto.nombre}
      </ThemedText>

      <View
        style={styles.receiptRow}
      >
        <ThemedText>
          Cantidad:
        </ThemedText>

        <ThemedText>
          {item.cantidad}
        </ThemedText>
      </View>

      <View
        style={styles.receiptRow}
      >
        <ThemedText>
          Precio unitario:
        </ThemedText>

        <ThemedText>
          Bs.{' '}
          {
            item.producto
              .precioVenta
          }
        </ThemedText>
      </View>

      <View
        style={styles.receiptRow}
      >
        <ThemedText>
          Subtotal:
        </ThemedText>

        <ThemedText>
          Bs.{' '}
          {item.cantidad *
            item.producto
              .precioVenta}
        </ThemedText>
      </View>
    </View>
  )
)}

            <ThemedText
              style={styles.total}
            >
              Total:
              Bs.
             Bs. {Number(factura.total).toFixed(2)}
            </ThemedText>

            <TouchableOpacity
              style={[
                styles.btn,
                {
                  backgroundColor:
                    colors.tint,
                },
              ]}
              onPress={() =>
                setFacturaVisible(
                  false
                )
              }
            >
              <ThemedText
                style={{
                  color: colors.text,
                }}
              >
                Cerrar
              </ThemedText>
            </TouchableOpacity>
<TouchableOpacity
  style={[
    styles.btn,
    {
      backgroundColor:
        '#2563eb',
      marginTop: 10,
    },
  ]}
  onPress={() =>imprimirRecibo(factura)}
>
  <ThemedText
    style={{
      color: colors.text,
    }}
  >
    Imprimir / Compartir PDF
  </ThemedText>
</TouchableOpacity>
          </View>
        </ScrollView>
      </ThemedView>
    );
  }

  /* ===================== UI ===================== */

return (
  <ThemedView style={styles.container}>
    <TabHeader
      title={
        user?.role === 'admin'
          ? 'Panel Admin'
          : 'Carrito'
      }
    />

    {/* ================= CLIENTE ================= */}

    {user?.role !== 'admin' ? (
      <>
        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{
            padding: 12,
            paddingBottom: 220,
          }}
          showsVerticalScrollIndicator={
            false
          }
        >
          <ThemedText
            style={styles.bigTitle}
          >
            Mi carrito
          </ThemedText>

          {items.length === 0 ? (
            <ThemedText>
              No tienes productos reservados
            </ThemedText>
          ) : (
            items.map((item: any) => (
              <View
                key={item.producto.id}
                style={[styles.ticket,{backgroundColor:colors.card}]}
              >
                <ThemedText>
                  {
                    item.producto.nombre
                  }
                </ThemedText>

                <ThemedText>
                  Precio: Bs.
                  {
                    item.producto
                      .precioVenta
                  }
                </ThemedText>

                <ThemedText>
                  cantidad disponible:
                  {
                    item.producto
                      .stock
                  }
                </ThemedText>

                {/* CANTIDAD */}

                <View
                  style={{
                    flexDirection:
                      'row',
                    alignItems:
                      'center',
                    marginTop: 10,
                    gap: 10,
                  }}
                >
                  <TouchableOpacity
                    style={
                      styles.btnCantidad
                    }
                    onPress={() =>
                      actualizarCantidad(
                        item.producto.id,
                        item.cantidad -
                          1
                      )
                    }
                  >
                    <ThemedText
                      style={{
                        color:
                          colors.text,
                      }}
                    >
                      -
                    </ThemedText>
                  </TouchableOpacity>

                  <TextInput
                    value={String(
                      item.cantidad
                    )}
                    onChangeText={(
                      text
                    ) => {
                      const cantidad =
                        Number(
                          text
                        );

                      if (
                        !isNaN(
                          cantidad
                        )
                      ) {
                        actualizarCantidad(
                          item
                            .producto
                            .id,
                          cantidad
                        );
                      }
                    }}
                    keyboardType="numeric"
                    style={[
                      styles.inputCantidad,{color:colors.text}
                    ]}
                  />

                  <TouchableOpacity
                    style={
                      styles.btnCantidad
                    }
                    onPress={() =>
                      actualizarCantidad(
                        item.producto.id,
                        item.cantidad +
                          1
                      )
                    }
                  >
                    <ThemedText
                      style={{
                        color:
                          colors.text,
                      }}
                    >
                      +
                    </ThemedText>
                  </TouchableOpacity>
                </View>

                <ThemedText
                  style={{
                    marginTop: 10,
                    fontWeight:
                      '700',
                  }}
                >
                  Subtotal: Bs.
                  {(
                    item.producto.precioVenta *
                    item.cantidad
                  ).toFixed(2)}
                </ThemedText>

                <TouchableOpacity
                  style={[
                    styles.btn,
                    {
                      backgroundColor:
                        '#ef4444',
                      marginTop: 10,
                    },
                  ]}
                  onPress={() =>
                    removerDelCarrito(
                      item.producto.id
                    )
                  }
                >
                  <ThemedText
                    style={{
                      color:
                        colors.text,
                    }}
                  >
                    Quitar
                  </ThemedText>
                </TouchableOpacity>
              </View>
            ))
          )}
        </ScrollView>

        {/* ================= FOOTER FIJO ================= */}

        {items.length > 0 && (
          <View
            style={[styles.footerPago,{backgroundColor: colors.footer,borderTopColor: colors.border}]}
          >
            <ThemedText
              style={styles.total}
            >
              TOTAL: Bs. {Number(total).toFixed(2)}
            </ThemedText>

            <TouchableOpacity
              style={[
                styles.btn,
                {
                  backgroundColor:
                    '#22c55e',
                    marginTop: 60,
                    bottom: 50,
                },
              ]}
              onPress={() =>
                confirmarCompra(
                  'Efectivo'
                )
              }
            >
              <ThemedText
                style={{
                  color: colors.text,
                }}
              >
                Comprar en efectivo
              </ThemedText>
            </TouchableOpacity>

            <TouchableOpacity
              style={[
                styles.btn,
                {
                  backgroundColor:
                    '#2563eb',
                  marginTop: 10,
                  bottom: 50,
                },
              ]}
              onPress={() =>
                setMostrarQR(true)
                
              }
              
            >

              <ThemedText
                style={{
                  color: colors.text,
                }}
              >
                Pagar con QR
              </ThemedText>
            </TouchableOpacity>

                          {mostrarQR && (
  <View style={styles.qrContainer}>
    
        <TouchableOpacity
      style={[
        styles.btn,
        {
          backgroundColor: '#22c55e',
          marginTop:'auto',
        },
      ]}
      onPress={() =>
        confirmarCompra('QR')
      }
    >
      <ThemedText
        style={{
          color: colors.text,
        }}
      >
        Confirmar pago QR
      </ThemedText>
    </TouchableOpacity>
    <Image
      source={qrImage}
      style={styles.qrImage}
      resizeMode="contain"
    />

<TouchableOpacity
      style={[
        styles.btn,
        {
          backgroundColor: '#ef4444',
          marginTop: -20,
        },
      ]}
      onPress={() =>
        setMostrarQR(false)
      }
    >
      <ThemedText
        style={{
          color: colors.text,
        }}
      >
        Cancelar
      </ThemedText>
    </TouchableOpacity>

  </View>
)}
          </View>
        )}
        
{/* ================= HISTORIAL CLIENTE ================= */}

<View
  style={{
    marginTop: 0,
    paddingBottom: 0,
    bottom:-8,
  }}
>
  <TouchableOpacity
    style={styles.accordionBtn}
    onPress={() =>
      setHistorialVisible(
        !historialVisible
      )
    }
  >
    <ThemedText
      style={styles.accordionText}
    >
      {historialVisible
        ? '▼'
        : '▶'} Mi historial de compras
    </ThemedText>
  </TouchableOpacity>

  {historialVisible &&
    ventasOrdenadas.map(
      (v: any) => (
        <View
          key={v.id}
          style={[styles.ticket,{backgroundColor:colors.card}]}
        >
          <ThemedText>
            {v.receipt_id}
          </ThemedText>

          <ThemedText>
            {formatFecha(
              v.created_at
            )}
          </ThemedText>

          <ThemedText>
            Método:
            {' '}
            {v.metodo_pago}
          </ThemedText>

          <ThemedText
            style={
              styles.ticketTotal
            }
          >
            Total:
            {' '}
           Bs. {Number(v.total).toFixed(2)}
          </ThemedText>

          <TouchableOpacity
            style={[
              styles.btn,
              {
                backgroundColor:
                  '#2563eb',
                marginTop: 10,
              },
            ]}
            onPress={() =>
              setReciboDetalle(v)
            }
          >
            <ThemedText
              style={{
                color: colors.text,
              }}
            >
              Ver recibo
            </ThemedText>
          </TouchableOpacity>

          <TouchableOpacity
            style={[
              styles.btn,
              {
                backgroundColor:
                  '#22c55e',
                marginTop: 10,
              },
            ]}
            onPress={() =>
              imprimirRecibo({
                ...v,
                cliente:
                  v.usuario_nombre,
                carnet:
                  v.profiles
                    ?.carnet ||
                  'N/A',
                metodoPago:
                  v.metodo_pago,
                fecha:
                  v.created_at,
              })
            }
          >
            <ThemedText
              style={{
                color: colors.text,
              }}
            >
              Imprimir PDF
            </ThemedText>
          </TouchableOpacity>
        </View>
      )
    )}
</View>

      </>
    ) : (
      /* ================= ADMIN ================= */

      <ScrollView
        contentContainerStyle={{
          padding: 12,
        }}
      >
        <View>
          <ThemedText
            style={styles.bigTitle}
          >
            Reportes de ventas
          </ThemedText>

<View style={styles.dashboardRow}>

  <View style={[styles.dashboardCard,{backgroundColor: colors.card}]}>
    <ThemedText style={styles.dashboardTitle}>
      Ingresos Totales
    </ThemedText>

    <ThemedText style={styles.dashboardAmount}>
      Bs. {totalVentas.toFixed(2)}
    </ThemedText>
  </View>

  <View style={[styles.dashboardCard,{backgroundColor: colors.card}]}>
    <ThemedText style={styles.dashboardTitle}>
      Ganancia Real
    </ThemedText>

    <ThemedText style={styles.dashboardAmount}>
      Bs. {gananciaReal.toFixed(2)}
    </ThemedText>
  </View>

</View>

<View style={styles.chartContainer}>

  <ThemedText
    style={styles.chartTitle}
  >
    Estadísticas de ventas por mes
  </ThemedText>

  {ventasOrdenadas.length > 0 && (
    <LineChart
      data={chartData}

      width={
        Dimensions.get(
          'window'
        ).width - 40
      }

      height={220}

      yAxisSuffix=" Bs"

      chartConfig={{
        backgroundColor:
          '#111827',

        backgroundGradientFrom:
          '#111827',

        backgroundGradientTo:
          '#1f2937',

        decimalPlaces: 0,

        color: (
          opacity = 1
        ) =>
          `rgba(34,197,94,${opacity})`,

        labelColor: (
          opacity = 1
        ) =>
          `rgba(255,255,255,${opacity})`,

        propsForDots: {
          r: '5',
        },
      }}

      bezier

      style={{
        marginTop: 10,
        borderRadius: 16,
      }}
    />
  )}

</View>

<View style={styles.searchRow}>

  <TextInput
    placeholder="Buscar carnet"
    placeholderTextColor="#aaa"
    value={buscarCarnet}
    onChangeText={setBuscarCarnet}
    style={styles.searchInput}
  />

  <TextInput
    placeholder="Buscar recibo"
    placeholderTextColor="#aaa"
    value={buscarRecibo}
    onChangeText={setBuscarRecibo}
    style={styles.searchInput}
  />

</View>

<TouchableOpacity
  style={styles.accordionBtn}
  onPress={() =>
    setHistorialVisible(
      !historialVisible
    )
  }
>
  <ThemedText
    style={styles.accordionText}
  >
    {historialVisible
      ? '▼'
      : '▶'} Historial de ventas
  </ThemedText>
</TouchableOpacity>

{historialVisible && (

<View>

  {/* CABECERA */}

  <View style={styles.tableHeader}>

    <ThemedText style={styles.headerCell}>
      Cliente
    </ThemedText>

    <ThemedText style={styles.headerCell}>
      Recibo
    </ThemedText>

    <ThemedText style={styles.headerCell}>
      Total
    </ThemedText>

    <ThemedText style={styles.headerCell}>
      Acción
    </ThemedText>

  </View>

  {ventasOrdenadas.map(
    (v: any) => (

      <View
        key={v.id}
        style={styles.tableRow}
      >

        <ThemedText
          style={styles.tableCell}
          numberOfLines={1}
        >
          {v.usuario_nombre}
        </ThemedText>

        <ThemedText
          style={styles.tableCell}
          numberOfLines={1}
        >
          {v.receipt_id}
        </ThemedText>

        <ThemedText
          style={styles.tableCell}
        >
          Bs. {v.total}
        </ThemedText>

        <TouchableOpacity
          style={styles.miniBtn}
          onPress={() =>
            setReciboDetalle(v)
          }
        >
          <ThemedText
            style={{
              color: colors.text,
              fontSize: 12,
            }}
          >
            Ver
          </ThemedText>
        </TouchableOpacity>

      </View>

    )
  )}

</View>

)}
        </View>
      </ScrollView>
    )}
  </ThemedView>
);
}

/* ===================== STYLES ===================== */

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  contentContainer: {
  padding: 12,
  paddingBottom: 140,
  flexGrow: 1,
  },

  input: {
    borderWidth: 1,
    borderColor: '#374151',
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
    color: 'colors.text',
  },

  dateBtn: {
    borderWidth: 1,
    borderColor: '#374151',
    padding: 10,
    borderRadius: 8,
    marginBottom: 10,
  },

  bigTitle: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 10,
  },

  btn: {
    padding: 10,
    borderRadius: 8,
    alignItems: 'center',
  },

  factura: {
    padding: 15,
    borderRadius: 12,
    borderWidth: 1,
  },

  receiptId: {
    fontWeight: '700',
    marginVertical: 10,
  },

  receiptItem: {
    flexDirection: 'row',
    justifyContent:
      'space-between',
    marginVertical: 4,
  },

  total: {
    fontWeight: '700',
    marginTop: 10,
  },

  ticket: {
    padding: 12,
    borderRadius: 10,
    marginTop: 10,
  },

  ticketTotal: {
    fontWeight: '700',
    marginTop: 8,
  },

  btnCantidad: {
  backgroundColor: '#374151',
  width: 35,
  height: 35,
  borderRadius: 8,
  justifyContent: 'center',
  alignItems: 'center',
},

inputCantidad: {
  borderWidth: 1,
  borderColor: '#374151',
  width: 60,
  height: 40,
  textAlign: 'center',
  color: 'colors.text',
  borderRadius: 8,
},
footerPago: {
  position: 'absolute',
  bottom: 0,
  left: 0,
  right: 0,
  padding: 15,
  borderTopWidth: 1,
},
receiptCard: {
  marginTop: 12,
  padding: 10,
  borderRadius: 10,
  backgroundColor: 'colors.card',
},

receiptProduct: {
  fontWeight: '700',
  fontSize: 16,
  marginBottom: 8,
},

receiptRow: {
  flexDirection: 'row',
  justifyContent:
    'space-between',
  marginTop: 4,

  
},
dashboardCard: {
  flex: 1,
  padding: 20,
  borderRadius: 14,
},
dashboardRow: {
  flexDirection: 'row',
  gap: 12,
  marginBottom: 15,
},
searchRow: {
  flexDirection: 'row',
  gap: 12,
  marginBottom: 10,
},

searchInput: {
  flex: 1,
  borderWidth: 1,
  borderColor: '#374151',
  padding: 10,
  borderRadius: 8,
  color: 'colors.text',
},

dashboardTitle: {
  fontSize: 16,
  color: '#9ca3af',
},

dashboardAmount: {
  fontSize: 30,
  fontWeight: '800',
  color: '#22c55e',
  marginTop: 10,
},
tableHeader: {
  flexDirection: 'row',
  paddingVertical: 12,
  borderRadius: 10,
  marginBottom: 8,
  backgroundColor: 'colors.tableHeader',
},

tableRow: {
  flexDirection: 'row',
  backgroundColor: 'colors.card',
  paddingVertical: 10,
  borderRadius: 10,
  marginBottom: 6,
  alignItems: 'center',
},

headerCell: {
  flex: 1,
  textAlign: 'center',
  fontWeight: '800',
},

tableCell: {
  flex: 1,
  textAlign: 'center',
  fontSize: 12,
  paddingHorizontal: 4,
},

miniBtn: {
  flex: 1,
  backgroundColor: '#2563eb',
  marginHorizontal: 4,
  paddingVertical: 6,
  borderRadius: 6,
  alignItems: 'center',
}, 

chartContainer: {
  backgroundColor: 'colors.card',
  padding: 15,
  borderRadius: 14,
  marginBottom: 20,
  alignItems: 'center',
},

chartTitle: {
  fontSize: 16,
  fontWeight: '700',
  marginBottom: 10,
},

accordionBtn: {
  backgroundColor: 'colors.tableHeader',
  padding: 14,
  borderRadius: 12,
  marginBottom: 10,
},

accordionText: {
  fontSize: 16,
  fontWeight: '700',
},
qrContainer: {
  marginTop: 25,
  alignItems: 'center',
  bottom:60,
},

qrImage: {
  width: 310,
  height: 250,
  borderRadius: 25,
  marginTop: 40,
  bottom:35,
},
});
